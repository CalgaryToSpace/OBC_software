/*
 * threads.h
 *
 *  Created on: Dec 28, 2021
 *      Author: Matthew
 */

#ifndef INC_THREADS_H_
#define INC_THREADS_H_

// Test function
void StartTest1(void *argument);

//Test function
void StartTest2(void *argument);



#endif /* INC_THREADS_H_ */
